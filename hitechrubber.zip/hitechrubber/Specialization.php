<?php include('includes/header.php');?>
	<div id="content" class="site-content">
		<div class="page-header">
		    <div class="container">
		        <div class="breadc-box no-line">
		            <div class="row">
		                <div class="col-md-12">
		                    <h3 class="page-title">Our Specialization</h3>
		                    <ul id="breadcrumbs" class="breadcrumbs none-style">
		                        <li><a href="index.php">Home</a></li>
		                        <li class="active">Our Specialization</li>
		                    </ul>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<section>
			<div class="container">
				<div class="row flex-row">
					<div class="col-md-12 col-sm-12 align-self-center">
						<h3 class="text-primary">Our Specialization</h3>

						<p align="justify">We make rubber gaskets for temperature resistant from – 72 dg. C to high temp. Resistant for 110 dg. C. 125 dg. C. 148 dg. C. 200 dg. C, 250 dg. C, 315 dg. C, Minimum Compression set and permanent set, Resistant to Gas, Sea Water, and Oil (Edible and Non-Edible) steam etc. Resistant to impact shocks, vibration, Radiation, Corona- Ozone, Infrared, Ultra Violet Rays. We manufacture rubber Gaskets to withstand/resistant destructive effect of most of the organic & inorganic fluids. Specially compounds have also been developed to serve the severe conditions in application.</p>
						<div class="industris-space-xs"></div>
					</div>
				</div>
		    </div>
		</section>
	</div>


	<section class="bg-contact-info">
	  <div class="container">
	    <div class="row">
	      <div class="col-md-12">
	        <form class="form-contact" action="contact.php" method="post">
	          <h3>Contact Us</h3>
	          <div class="row">
	            <div class="col-md-4 form-group">
	              <input type="text" name="your_name" id="your-name" class="form-control" placeholder="Your name" required>
	            </div>
	            <div class="col-md-4 form-group">
	              <input type="number" name="phone_number" id="phone-number" class="form-control" placeholder="Phone number" required>
	            </div>
	            <div class="col-md-4 form-group">
	              <input type="email" name="your_email" id="your-email" class="form-control" placeholder="Email Address" required>
	            </div>
	            <div class="col-md-12 form-group">
	              <textarea type="text" rows="6" name="your_message" id="your-message" class="form-control" placeholder="your message" required></textarea>
	            </div>
	            <div class="col-md-12">
	              <input type="submit" value="Submit" class="wpcf7-form-control wpcf7-submit btn btn-primary">
	            </div>
	          </div>
	        </form>
	      </div>
	    </div>
	    </div>
	</section>

<?php include('includes/footer.php'); ?>

	    