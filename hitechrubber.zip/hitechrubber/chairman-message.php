<?php include('includes/header.php');?>
	<div id="content" class="site-content">
		<div class="page-header">
		    <div class="container">
		        <div class="breadc-box no-line">
		            <div class="row">
		                <div class="col-md-12">
		                    <h3 class="page-title">Chairman Message</h3>
		                    <ul id="breadcrumbs" class="breadcrumbs none-style">
		                        <li><a href="index.php">Home</a></li>
		                        <li class="active">Chairman Message</li>
		                    </ul>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<section>
			<div class="container">
				<div class="row flex-row">
					<div class="col-md-12 col-sm-12 align-self-center">
						<h3 class="text-primary">Chairman Message</h3>
						<p align="justify">Passionate Team to the right job has helped a mass of successful stories!</p>
						<p align="justify">For almost a decade Hi Tech Rubber has emerged as the industrial sealant rubber product manufacturing firm</p>

						<p align="justify">With highly versatile machinery and skill developed labour a vast range of quality products whch spanning successful brands in the rubber industry. We are very happy that Hi tech has the best team who works as a family and they come with rich experience in manufacturing rubber products.</p>
						<p align="justify">Thanks to our capacity to adapt to dynamic innovations while keeping the remarkable needs of our regarded clients at the front line of the company’s core interest.</p>
						<p align="justify">Our strength is developed by our unique ideas and values, wherein we develop excellent and smart services by giving equal importance to all stakeholders involved in the chain, such as our diverse talented work team, partners, clients, and the society.</p>
						<p align="justify">Finding new ideas and strategies to creating brilliant business opportunities and giving value-added services to our clients, we develop new products and services and induce excellent techniques to develop our products technically tested.</p>
						<p align="justify">All you need to do is to let us know how we can improve our products and what kind of new product range we can launch. Our team is happy to answer your question about our products and services. Innovative ideas not only improve processes but also gain the success of your business.</p>
						<p align="justify">We stand by the Motto; Clients Satisfaction is our success. Thanks</p>
						<h4>Shiva Gupta (Director)</h4>
						<h4>Hi- Tech Rubber</h4>
						<div class="industris-space-xs"></div>
					</div>
				</div>
		    </div>
		</section>
	</div>


	<section class="bg-contact-info">
	  <div class="container">
	    <div class="row">
	      <div class="col-md-12">
	        <form class="form-contact" action="contact.php" method="post">
	          <h3>Contact Us</h3>
	          <div class="row">
	            <div class="col-md-4 form-group">
	              <input type="text" name="your_name" id="your-name" class="form-control" placeholder="Your name" required>
	            </div>
	            <div class="col-md-4 form-group">
	              <input type="number" name="phone_number" id="phone-number" class="form-control" placeholder="Phone number" required>
	            </div>
	            <div class="col-md-4 form-group">
	              <input type="email" name="your_email" id="your-email" class="form-control" placeholder="Email Address" required>
	            </div>
	            <div class="col-md-12 form-group">
	              <textarea type="text" rows="6" name="your_message" id="your-message" class="form-control" placeholder="your message" required></textarea>
	            </div>
	            <div class="col-md-12">
	              <input type="submit" value="Submit" class="wpcf7-form-control wpcf7-submit btn btn-primary">
	            </div>
	          </div>
	        </form>
	      </div>
	    </div>
	    </div>
	</section>



<?php include('includes/footer.php'); ?>

	    