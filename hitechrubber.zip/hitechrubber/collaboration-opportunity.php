<?php include('includes/header.php'); ?>

    <div id="content" class="site-content">
      <div class="page-header" style="background: url('https://via.placeholder.com/1920x450.png') no-repeat center center;">
          <div class="container">
              <div class="breadc-box no-line">
                  <div class="row">
                      <div class="col-md-12">
                          <h2 class="page-title">Contact us</h2>
                          <ul id="breadcrumbs" class="breadcrumbs none-style">
                              <li><a href="index.html">Home</a></li>
                              <li class="active">Contact Us</li>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>
      </div>

    </div>
      
<?php include('includes/footer.php'); ?>