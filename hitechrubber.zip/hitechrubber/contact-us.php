<?php include('includes/header.php'); ?>
    <div id="content" class="site-content">
      <div class="page-header">
          <div class="container">
              <div class="breadc-box no-line">
                  <div class="row">
                      <div class="col-md-12">
                          <h2 class="page-title">Contact Us</h2>
                          <ul id="breadcrumbs" class="breadcrumbs none-style">
                              <li><a href="index.php">Home</a></li>
                              <li class="active">Contact Us</li>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <section class="bg-contact-info">
        <div class="container">
          <div class="row">
            <div class="col-md-6 col-sm-12">
              <h4 class="text-primary">CONTACT INFO</h4>
              <div class="contact-info">
                <h2><span class="text-primary">+91-8265888882</span> </h2>
                <p><i class="icon ion-md-mail"></i> info@hitechrubber.co.in</p>
                <p><i class="icon ion-md-pin"></i> Meerut Rubber Industries 41 A, Mohakampur Industrial Area, Phase – 1,Delhi Road, Meerut (U.P) PIN – 250002 </p>
              </div>
              <div class="space-industris" style="height: 40px;"></div>
              <hr>
            </div>
            <div class="col-md-12">
              <form class="form-contact" action="contact.php" method="post">
                <h3>Contact Us</h3>
                <div class="row">
                  <div class="col-md-4 form-group">
                    <input type="text" name="your_name" id="your-name" class="form-control" placeholder="Your name" required>
                  </div>
                  <div class="col-md-4 form-group">
                    <input type="number" name="phone_number" id="phone-number" class="form-control" placeholder="Phone number" required>
                  </div>
                  <div class="col-md-4 form-group">
                    <input type="email" name="your_email" id="your-email" class="form-control" placeholder="Email Address" required>
                  </div>
                  <div class="col-md-12 form-group">
                    <textarea type="text" rows="6" name="your_message" id="your-message" class="form-control" placeholder="your message" required></textarea>
                  </div>
                  <div class="col-md-12">
                    <input type="submit" value="Submit" class="wpcf7-form-control wpcf7-submit btn btn-primary">
                  </div>
                </div>
              </form>
            </div>
          </div>
          </div>
      </section>

      <section>
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <h3>View map:</h3>
              <div class="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3491.2467483928713!2d77.67429721427027!3d28.950404982293506!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390c640d2ad11ceb%3A0xe361bf307df2d229!2smeerutrubberindustries!5e0!3m2!1sen!2sin!4v1607659703358!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
              </div>
            </div>
          </div>
        </div>
      </section>
      
    </div>
      
<?php include('includes/footer.php'); ?>