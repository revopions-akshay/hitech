<?php include('includes/header.php');?>
	<div id="content" class="site-content">
		<div class="page-header">
		    <div class="container">
		        <div class="breadc-box no-line">
		            <div class="row">
		                <div class="col-md-12">
		                    <h3 class="page-title">Continuously Updated Technology and Practices</h3>
		                    <ul id="breadcrumbs" class="breadcrumbs none-style">
		                        <li><a href="index.php">Home</a></li>
		                        <li class="active">Continuously Updated Technology and Practices</li>
		                    </ul>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<section>
			<div class="container">
				<div class="row flex-row">
					<div class="col-md-12 col-sm-12 align-self-center">
						<h3 class="text-primary">Continuously Updated Technology and Practices</h3>

						<p align="justify">We encourage the use of new technology and practices that enable us to produce and deliver world class products.</p>
						<h4>List of Hi-Tech Rubber Other Technical Facilities</h4>
						<ul>
							<li><a href="house-testing.php">In House Testing Facilities</a></li>
							<li><a href="collaboration-laboratories.php">Collaboration with NABL Accredited Laboratories</a></li>
							<li><a href="flexibility-innovation.php">Flexibility and Openness to Innovations</a></li>
						</ul>

						<h4>HI – Tech Rubber &amp; Engineering technical specifications include:</h4>
						<p>The Synthetic Rubbers</p>
						<ul>
							<li>NITRILE (Acrylonitrile-butadiene Rubbers)</li>
							<li>NEOPRENE (P o l y c h l- o r o p r e n e)</li>
							<li>SBR (Styrene-butadiene rubbers)</li>
							<li>EPDM (Ethylene-propylene rubbers)</li>
							<li>BUTYL (Isobutene-isoprene Rubbers)</li>
							<li>HYPALON</li>
							<li>SILICONE</li>
							<li>VITON (Fluoro rubbers)</li>
							<li>AFLAS</li>
						</ul>
						<div class="industris-space-xs"></div>
					</div>
				</div>
		    </div>
		</section>
	</div>

	<section class="bg-contact-info">
	  <div class="container">
	    <div class="row">
	      <div class="col-md-12">
	        <form class="form-contact" action="contact.php" method="post">
	          <h3>Contact Us</h3>
	          <div class="row">
	            <div class="col-md-4 form-group">
	              <input type="text" name="your_name" id="your-name" class="form-control" placeholder="Your name" required>
	            </div>
	            <div class="col-md-4 form-group">
	              <input type="number" name="phone_number" id="phone-number" class="form-control" placeholder="Phone number" required>
	            </div>
	            <div class="col-md-4 form-group">
	              <input type="email" name="your_email" id="your-email" class="form-control" placeholder="Email Address" required>
	            </div>
	            <div class="col-md-12 form-group">
	              <textarea type="text" rows="6" name="your_message" id="your-message" class="form-control" placeholder="your message" required></textarea>
	            </div>
	            <div class="col-md-12">
	              <input type="submit" value="Submit" class="wpcf7-form-control wpcf7-submit btn btn-primary">
	            </div>
	          </div>
	        </form>
	      </div>
	    </div>
	    </div>
	</section>

<?php include('includes/footer.php'); ?>

	    


















