    <footer id="site-footer" class="site-footer bg-footer">
	        <div class="main-footer">
	            <div class="container-custom">
	                <div class="row">

	                    <div class="col-md-6 col-sm-6" style="text-align: center;">
	                    	<div class="widget-footer">
		                        <div id="custom_html-1" class="widget_text widget widget_custom_html">
		                            <div class="textwidget custom-html-widget">
		                            	<p style="font-size: 20px">Address:</p>
		                                <p style="font-size: 20px;">Meerut Rubber Industries 41 A, <br>Mohakampur Industrial Area, Phase – 1, <br>Delhi Road, Meerut (U.P) PIN – 250002</p>
		                            </div>
		                        </div>
		                    </div>
	                    </div>
                        <div class="col-md-6 col-sm-6" style="text-align: center;">
                        	<div class="widget-footer">
    	                        <div id="custom_html-1" class="widget_text widget widget_custom_html">
    	                            <div class="textwidget custom-html-widget">
    	                            	<p style="font-size: 20px">Contact Details:</p>
    	                                <p style="font-size: 20px">Phone No. : +91-8265888882</p>
    	                                <p style="font-size: 20px">Email : info@hitechrubber.co.in</p>
    	                            </div>
    	                        </div>
    	                    </div>
                        </div>


	                </div>
	            </div>
	        </div>
	        <!-- .main-footer -->
	        <div class="footer-bottom">
	            <div class="container-custom">
	            	<div class="row">
	            		<div class="col-md-12">
		                    <!-- ul class="topbar-left">
		                        <li><i class="icon ion-md-pin"></i>Meerut Rubber Industries 41 A, Mohakampur Industrial Area</li>
		                        <li><i class="icon ion-md-call"></i>+91-8265888882</li>
		                        <li><i class="icon ion-md-mail"></i>info@hitechrubber.co.in</li>
		                    </ul> -->
			        		<a id="back-to-top" href="#" class="btn btn-back-to-top pull-right">Back to top<i class="icon ion-ios-arrow-dropup-circle"></i></a>
			        	</div>
			        </div>
	            </div>
	        </div>
	        <!-- .copyright-footer -->
	    </footer>
	</div>

	<script src='js/jquery.min.js'></script>
	<script src='js/slick.min.js'></script>
	<script src='js/jquery.sticky.js'></script>
	<script src='js/countto.min.js'></script>
	<script src='js/jquery.magnific-popup.min.js'></script>
	<script src='js/jquery.isotope.min.js'></script>
	<script src='js/scripts.js'></script>
	<script src="js/particles.js"></script>
	<script src="js/app.js"></script>

	<!-- stats.js -->
	<script src="js/lib/stats.js"></script>
	<script>
	  var count_particles, stats, update;
	  stats = new Stats;
	  stats.setMode(0);
	  stats.domElement.style.position = 'absolute';
	  stats.domElement.style.left = '0px';
	  stats.domElement.style.top = '0px';
	  document.body.appendChild(stats.domElement);
	  count_particles = document.querySelector('.js-count-particles');
	  update = function() {
	    stats.begin();
	    stats.end();
	    if (window.pJSDom[0].pJS.particles && window.pJSDom[0].pJS.particles.array) {
	      count_particles.innerText = window.pJSDom[0].pJS.particles.array.length;
	    }
	    requestAnimationFrame(update);
	  };
	  requestAnimationFrame(update);
	</script>
</body>
</html>