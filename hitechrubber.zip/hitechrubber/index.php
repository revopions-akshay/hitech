<?php include('includes/header.php'); ?>

		<div class="slider" data-show="1" data-arrow="true">

			<div>
				<div class="slider-item">
					<img src="images/slider1.jpg" alt="" class="">
					<div class="container">
						<div class="row">
							<div class="col-md-9">
								<!-- <div class="slider-content">
									<h4>WELCOME TO INDUSTRIS...!</h4>
									<h1>The leading provider  of Industrial </h1>
									<a class="btn btn-primary" href="#">Explore now</a>
								</div> -->
							</div>
						</div>
					</div>
				</div>
			</div>

			<div>
				<div class="slider-item">
					<img src="images/slider2.jpg" alt="" class="">
					<div class="container">
						<div class="row">
							<div class="col-md-9">
								<!-- <div class="slider-content">
									<h4>WELCOME TO INDUSTRIS...!</h4>
									<h1>Leader in power Automation </h1>
									<a class="btn btn-primary" href="#">Explore now</a>
								</div> -->
							</div>
						</div>
					</div>
				</div>
			</div>

			<div>
				<div class="slider-item">
					<img src="images/slider3.jpg" alt="" class="">
					<div class="container">
						<div class="row">
							<div class="col-md-9">
						<!-- 		<div class="slider-content">
									<h4>WELCOME TO INDUSTRIS...!</h4>
									<h1>Best solution for Industrial &amp; Factories </h1>
									<a class="btn btn-primary" href="#">Explore now</a>
								</div> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<section class="no-padding-bottom">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h3>Our Product</h3>
						<div class="industris-space-30"></div>

						<div class="services-block-left">
							<div class="services-slider-img-left">
								<img src="https://via.placeholder.com/132x132.png" alt="">
							</div>
						</div>

						<div class="services-slider" data-show="3" data-arrow="true">

							<div class="services-item">
								<div class="services-box">
									<div class="services-icon">
										<img src="images/phe.jpg" height="174" width="142" alt="">
									</div>
									<div class="services-content">
										<h3><a href="services-detail.html">Plate Heat Exchanger</a></h3>
										<p align="justify">All plate heat exchanger gaskets are manufactured in accordance with a rigorous quality control procedure. With our gasket testing facilities,</p>
										<a class="view-detail" href="phe-heat-exchanger.php">View details<i class="icon ion-md-add-circle-outline"></i></a>
									</div>
								</div>
							</div>

							<div class="services-item">
								<div class="services-box">
									<div class="services-icon">
										<img src="images/butterfly.jpg" height="174" width="142" alt="">
									</div>
									<div class="services-content">
										<h3><a href="services-detail.html">Butterfly Valves</a></h3>
										<p align="justify">A butterfly valve is from a family of valves called quarter-turn valves. In operation, the valve is fully open or closed when the disc is rotated a quarter turn.</p>
										<div class="industris-space-10"></div>
										<a class="view-detail" href="butterfly-valves.php">View details<i class="icon ion-md-add-circle-outline"></i></a>
									</div>
								</div>
							</div>

							<div class="services-item">
								<div class="services-box">
									<div class="services-icon">
										<img src="images/oring.jpg" height="174" width="142" alt="">
									</div>
									<div class="services-content">
										<h3><a href="services-detail.html">General Items</a></h3>
										<p>Hi Tech Rubber Provide the general item like that O Ring, Flat Ring, Rubber Diaphraghm etc</p>
										<a class="view-detail" href="general-item.php">View details<i class="icon ion-md-add-circle-outline"></i></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="industris-space-90"></div>
		</section>	

		<section class="bg-light padding-bottom-medium">
			<div class="container">
				<div class="row flex-row">

					<div class="col-md-6">
						<h3>Latest News & Updates</h3>
					</div>
					<div class="col-md-6 text-right align-self-end">
						<a class="industris-lineheight" href="news.html">View all post<i class="icon ion-md-add-circle-outline"></i></a>
					</div>
				</div>
				<div class="industris-space-50"></div>

				<div class="row">
					<div class="col-md-4 col-sm-6 col-xs-12">
				        <article class="post-box post type-post entry">
				            <div class="entry-media">
				                <a href="post.html">
				                    <img src="https://via.placeholder.com/720x400.png" alt="">
				                </a>
				            </div>
				            <div class="inner-post">
				                <header class="entry-header">

				                    <div class="entry-meta">
				                        <span class="posted-on">
				                        	<span class="entry-date published">May 30, 2019</span>
				                        </span>
				                        <span class="posted-in">
				                        	<a href="#" rel="category tag">Oil & Gas</a>
				                        </span>
				                    </div>
				                    <!-- .entry-meta -->
				                    <h3 class="entry-title"><a href="post.html" rel="bookmark">Five Predictions for IoT in 2019 and beyond</a></h3>
				                </header>
				                <!-- .entry-header -->

				                <div class="entry-summary">
				                    <p> Telenor Connexion has worked with analysts from Stockholm-based consulting firm Northstream to...</p>
				                </div>
				                <!-- .entry-content -->

				                <footer class="entry-footer">
				                    <a class="post-link" href="post.html">Read more<i class="icon ion-md-add-circle-outline"></i></a>
				                </footer>
				                <!-- .entry-footer -->
				            </div>
				        </article>
				    </div>

		    		<div class="col-md-4 col-sm-6 col-xs-12">
				        <article class="post-box post type-post entry">
				            <div class="entry-media">
				                <a href="post.html">
				                    <img src="https://via.placeholder.com/720x400.png" alt="">
				                </a>
				            </div>
				            <div class="inner-post">
				                <header class="entry-header">

				                    <div class="entry-meta">
				                        <span class="posted-on">
				                        	<span class="entry-date published">May 30, 2019</span>
				                        </span>
				                        <span class="posted-in">
				                        	<a href="#" rel="category tag">Oil & Gas</a>
				                        </span>
				                    </div>
				                    <!-- .entry-meta -->
				                    <h3 class="entry-title"><a href="post.html" rel="bookmark">Wrap-up: The Japan-Sweden Business Summit</a></h3>
				                </header>
				                <!-- .entry-header -->

				                <div class="entry-summary">
				                    <p> “Future technologies will continue to increase the possibilities within IoT in general, and transportation...</p>
				                </div>
				                <!-- .entry-content -->

				                <footer class="entry-footer">
				                    <a class="post-link" href="post.html">Read more<i class="icon ion-md-add-circle-outline"></i></a>
				                </footer>
				                <!-- .entry-footer -->
				            </div>
				        </article>
				    </div>

		    		<div class="col-md-4 col-sm-6 col-xs-12">
				        <article class="post-box post type-post entry">
				            <div class="entry-media">
				                <a href="post.html">
				                    <img src="https://via.placeholder.com/720x400.png" alt="">
				                </a>
				            </div>
				            <div class="inner-post">
				                <header class="entry-header">

				                    <div class="entry-meta">
				                        <span class="posted-on">
				                        	<span class="entry-date published">May 30, 2019</span>
				                        </span>
				                        <span class="posted-in">
				                        	<a href="#" rel="category tag">Oil & Gas</a>
				                        </span>
				                    </div>
				                    <!-- .entry-meta -->
				                    <h3 class="entry-title"><a href="post.html" rel="bookmark">The brains behind Uber’s autonomous future</a></h3>
				                </header>
				                <!-- .entry-header -->

				                <div class="entry-summary">
				                    <p> Uber technology chief Raquel Urtasun is certain of one thing — that there will be self-driving cars, trucks...</p>
				                </div>
				                <!-- .entry-content -->

				                <footer class="entry-footer">
				                    <a class="post-link" href="post.html">Read more<i class="icon ion-md-add-circle-outline"></i></a>
				                </footer>
				                <!-- .entry-footer -->
				            </div>
				        </article>
				    </div>

				</div>
			</div>
		</section>

	<?php include('includes/footer.php'); ?>