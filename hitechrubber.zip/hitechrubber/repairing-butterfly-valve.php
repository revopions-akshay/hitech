<?php include('includes/header.php');?>
	<div id="content" class="site-content">
		<div class="page-header">
			<!-- particles.js container -->
		    <div class="container">
		        <div class="breadc-box no-line">
		            <div class="row">
		                <div class="col-md-12">
		                		<h3 class="page-title">Reparing of All Types of Butterfly Valves</h3>
		                		<ul id="breadcrumbs" class="breadcrumbs none-style">
		                		    <li><a href="index.php">Home</a></li>
		                		    <li class="active">Reparing of All Types of Butterfly Valves</li>
		                		</ul>
		                    
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	
		<section>
			<div class="container">
				<div class="row flex-row">
					<div class="col-md-12 col-sm-12 align-self-center">
						<h3 class="text-primary">Spares of PHE</h3>
						<p align="justify">HI-TECH RUBBER Also provide with Re-furbishing services for all types of Plate heat exchangers of any make company. We have our skilled team that regulates …………</p>
						<h3 class="text-primary">Why Maintenance</h3>
						<p align="justify">Although Plate Heat Exchanger is high performance and trouble free but, overtime, their rubber gaskets deteriorate, and plates will develop lime deposits and become dirty. For this reason, it is necessary to periodically replace rubber gaskets, clean the units</p>
						<div class="industris-space-xs"></div>
					</div>
				</div>
		    </div>
		</section>


		<section class="bg-contact-info">
		  <div class="container">
		    <div class="row">
		      <div class="col-md-12">
		        <form class="form-contact" action="contact.php" method="post">
		          <h3>Contact Us</h3>
		          <div class="row">
		            <div class="col-md-4 form-group">
		              <input type="text" name="your_name" id="your-name" class="form-control" placeholder="Your name" required>
		            </div>
		            <div class="col-md-4 form-group">
		              <input type="number" name="phone_number" id="phone-number" class="form-control" placeholder="Phone number" required>
		            </div>
		            <div class="col-md-4 form-group">
		              <input type="email" name="your_email" id="your-email" class="form-control" placeholder="Email Address" required>
		            </div>
		            <div class="col-md-12 form-group">
		              <textarea type="text" rows="6" name="your_message" id="your-message" class="form-control" placeholder="your message" required></textarea>
		            </div>
		            <div class="col-md-12">
		              <input type="submit" value="Submit" class="wpcf7-form-control wpcf7-submit btn btn-primary">
		            </div>
		          </div>
		        </form>
		      </div>
		    </div>
		    </div>
		</section>

<?php include('includes/footer.php'); ?>

	    