<?php include('includes/header.php');?>
	<div id="content" class="site-content">
		<div class="page-header">
		    <div class="container">
		        <div class="breadc-box no-line">
		            <div class="row">
		                <div class="col-md-12">
		                    <h3 class="page-title">Spares PHE Plates</h3>
		                    <ul id="breadcrumbs" class="breadcrumbs none-style">
		                        <li><a href="index.php">Home</a></li>
		                        <li class="active">Spares PHE Plates</li>
		                    </ul>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<section>
			<div class="container">
				<div class="row flex-row">
					<div class="col-md-12 col-sm-12 align-self-center">
						<h3 class="text-primary">Spares PHE Plates</h3>
						<p align="justify">We can supply PHE replacement plates for the majority PHE brand, the plates can 100% replace with the original one, they are already widely used in aftermarket.</p>
						<p align="justify">HI-TECH RUBBER provides with high performance spare gasket plates of any models.</p>
						<div class="industris-space-xs"></div>
					</div>
				</div>
		    </div>
		</section>

		<section class="padding-bottom-medium">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="project-filter" data-column="">
	
							<div id="projects" class="project-grid gallery row ">
								
								<div class="project-item clients events col-lg-4 col-sm-6">
						            <div class="inner">
						            	<a href="https://via.placeholder.com/720x841.png" class="image-link imghvr-shutter-out-vert" title="gallery zoom image">
						                    <img src="https://via.placeholder.com/720x841.png" alt=""> 
						                </a>
						            </div>
						        </div>
								<div class="project-item clients gproject col-lg-4 col-sm-6">
						            <div class="inner">
						            	<a href="https://via.placeholder.com/720x841.png" class="image-link imghvr-shutter-out-vert" title="gallery zoom image">
						                    <img src="https://via.placeholder.com/720x841.png" alt=""> 
						                </a>
						            </div>
						        </div>
								<div class="project-item events clients gproject col-lg-4 col-sm-6">
						            <div class="inner">
						            	<a href="https://via.placeholder.com/720x841.png" class="image-link imghvr-shutter-out-vert" title="gallery zoom image">
						                    <img src="https://via.placeholder.com/720x841.png" alt=""> 
						                </a>
						            </div>
						        </div>
							</div>
						</div>
					</div>
				</div>
		    </div>
		</section>


		<section class="bg-contact-info">
		  <div class="container">
		    <div class="row">
		      <div class="col-md-12">
		        <form class="form-contact" action="contact.php" method="post">
		          <h3>Contact Us</h3>
		          <div class="row">
		            <div class="col-md-4 form-group">
		              <input type="text" name="your_name" id="your-name" class="form-control" placeholder="Your name" required>
		            </div>
		            <div class="col-md-4 form-group">
		              <input type="number" name="phone_number" id="phone-number" class="form-control" placeholder="Phone number" required>
		            </div>
		            <div class="col-md-4 form-group">
		              <input type="email" name="your_email" id="your-email" class="form-control" placeholder="Email Address" required>
		            </div>
		            <div class="col-md-12 form-group">
		              <textarea type="text" rows="6" name="your_message" id="your-message" class="form-control" placeholder="your message" required></textarea>
		            </div>
		            <div class="col-md-12">
		              <input type="submit" value="Submit" class="wpcf7-form-control wpcf7-submit btn btn-primary">
		            </div>
		          </div>
		        </form>
		      </div>
		    </div>
		    </div>
		</section>



<?php include('includes/footer.php'); ?>

	    